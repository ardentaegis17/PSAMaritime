########  imports  ##########
from MSCFunction import *
from flask import Flask, json, request, render_template
import numpy as np
app = Flask(__name__)

def np_encoder(object):
    if isinstance(object, np.generic):
        return object.item()

#############################
# Additional code goes here #
#############################

@app.route('/')
def home_page():
    return render_template('index.html')

@app.route('/result', methods=['GET','POST'])
def result():
    # cannot use request.form.to_dict() because it doesn't seem to work with checkbox list
    departure = request.form["departure"]
    arrival = request.form["arrival"]
    time = request.form["time"]

    # mode_raw is from a checkbox
    mode_raw = request.form.getlist("mode")
    mode = "M"
    if "Air" not in mode_raw:
        mode = "S"
    elif "Ocean" not in mode_raw:
        mode = "A"

    # opti_raw is from a radio
    opti_raw = request.form["opti"]
    opti_dict = {"Time":0, "Cost":1, "Carbon":2}
    opti = opti_dict[opti_raw]

    connect = request.form["connect"]

    form_data = {"departure": departure, "arrival": arrival, "time": time, "mode_raw": mode_raw, "opti_raw": opti_raw, "connect": connect}
    output = MSCModel(mode, departure, arrival, time, opti, connect)

    return render_template("main.html", form_data = form_data, json_output = json.dumps(output, default = np_encoder))

#########  run app  #########
app.run(debug=True)