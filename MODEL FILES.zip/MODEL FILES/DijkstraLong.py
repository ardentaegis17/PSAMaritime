import heapq
from my_time import time_correct

# class for Routes
class Edge:
    def __init__(self, weight, start_vertex, target_vertex, start_time, end_time, imo = None):
        self.weight = weight
        self.start_vertex = start_vertex
        self.target_vertex = target_vertex
        self.start_time = start_time
        self.end_time = end_time
        self.imo = imo

# class for Ports
class Node:
    def __init__(self, name, mode = None, loc = None):
        self.name = name
        self.visited = False
        # previous node that we arrived to self node from
        self.predecessor = None
        self.neighbors = [] #contains all trips that can be taken from this port.
        self.min_distance = float("inf")
        self.time = 0 #tracks accumulated time 
        self.mode = mode
        self.loc = None


    
    def __lt__(self, other_node):
        return self.min_distance < other_node.min_distance
    
    def add_edge(self, weight, destination_vertex, start_time, end_time, imo):
        edge = Edge(weight, self, destination_vertex, start_time, end_time, imo)
        self.neighbors.append(edge)


# Dijkstra Algorithm
class Dijkstra:
    def __init__(self):
        self.heap = []
    
    def calculate(self, start_vertex, start_time, opti):
        start_vertex.min_distance = 0
        start_vertex.time = start_time
        heapq.heappush(self.heap, start_vertex)
        total_time = {} #used during time opti. tracks accumulated time at each node
        total_time[start_vertex.name] = 0
        route_data = {} #stores route information. Key is {prev. node ---> dest. node}

        
        while self.heap:
            # pop element with the lowest distance
            actual_vertex = heapq.heappop(self.heap)
            if actual_vertex.visited:
                continue
            #  consider the neighbors
            for edge in actual_vertex.neighbors:
                start = edge.start_vertex
                target = edge.target_vertex
                new_distance = start.min_distance + edge.weight

                if edge.imo == 'Multi!': #we assume that costs of switching from airport to seaport is negligible. (2 minutes)
                    edge.start_time = start.time + 100
                    edge.end_time = start.time + 200
                

                if opti == 0: #time optimised
                    # time_check: a voyage can be short, but if it takes a year to depart, we shouldn't wait for it.
                    time_check = time_correct((edge.end_time - start.time) / 1000000, start.time, edge.end_time)
                    if  time_check + total_time[start.name] < target.min_distance and start.time < edge.start_time:

                        #store the details of the route
                        if edge.imo == 'Multi!':
                            info = (edge.end_time, start.time, edge.imo, time_check, 'switch!')
                        else:
                            info = (edge.end_time, start.time, edge.imo, time_check, start.mode)

                        route_data[start.name, target.name] = info
  
                        target.min_distance = time_check + total_time[start.name]
                        total_time[target.name] = target.min_distance
                        target.time = edge.end_time
                        target.predecessor = start
                        heapq.heappush(self.heap, target)
                
                elif new_distance < target.min_distance and start.time < edge.start_time: #cost, carbon optimised
                    if edge.imo == 'Multi!':
                        info = (edge.end_time,start.time, edge.imo, edge.weight, 'switch!')
                    else:
                        info = (edge.end_time,start.time, edge.imo, edge.weight, start.mode)
                        
                    target.min_distance = new_distance
                    target.time = edge.end_time
                    target.predecessor = start
                    heapq.heappush(self.heap, target)

            
            actual_vertex.visited = True
            
        return route_data
    
    def get_shortest_path(self, vertex,route):
        if vertex.min_distance == float("inf"):
            return print("No path exists to your given destination.")
        else:
            print(f"The shortest path to the destination is {vertex.min_distance}")
            
        actual_vertex = vertex
        end_time = actual_vertex.time
        while actual_vertex is not None:
            prev = actual_vertex.name
            #print destination node's name and lat/long coordinates
            print((prev, actual_vertex.loc))
            actual_vertex = actual_vertex.predecessor
            #print the route from previous node to destination node
            print(route[actual_vertex.name,prev], end=" ")
            if actual_vertex.predecessor is None:
                #print the previous node's name and lat/long coordinates
                print((actual_vertex.name, actual_vertex.loc))
                start_time = actual_vertex.time
                break
            
        #calculate total time
        duration = str(time_correct((end_time - start_time) / 1000000, start_time, end_time))
        days = None
        hours = None
        for i in range(0,len(duration)):
            if duration[i] == '.':
                days = duration[:i]
                hours = duration[i+1:i+5]
                break
        
            


        #print total time
        print(f"The total time taken - {days} days and {hours} hours")


