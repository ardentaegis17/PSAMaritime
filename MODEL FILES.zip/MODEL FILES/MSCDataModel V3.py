import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from DijkstraLong import Node, Edge, Dijkstra #shortest path algo
from my_time import time_correct

###----------------------------------PART I: Preparing the DataSets and Dictionaries
#Datasets loaded here with pandas
#CHANGE FILE LOCATION TO WHERE IT'S STORED IN YOUR COMPUTER.
ocean_data = pd.read_excel(r'C:\Users\ongai\OneDrive\Desktop\Graph Theory\MSC Data\GlobalOceanSchedulesEdit.xlsx')
air_data = pd.ExcelFile(r'C:\Users\ongai\OneDrive\Desktop\Graph Theory\MSC Data\GlobalAirSchedules2.xlsx')
coord = pd.ExcelFile(r'C:\Users\ongai\OneDrive\Desktop\Graph Theory\MSC Data\Coordinates.xlsx')

##Changes made to the Coordinates File will be reflected here.
sea_points = coord.parse('Seaport').values.tolist()
air_points = coord.parse('Airport').values.tolist()
port_pairs = coord.parse('Codex').values.tolist()
flight_pairs = coord.parse('Flight Times').values.tolist()

sea_coord = {} #Lat Long coordinates for sea ports.
air_coord = {} #air ports.
codex = {} #dictionary for matching up a country's sea and air port.
flight_times_sg  = {} # Time needed to travel to another airport from Singapore's airport. 

def create_coord(points,dic):
    for lst in points:
        name, country, lat, long = lst
        dic[name] = (lat,long)
    return dic

def create_codex(pairs, dic):
    for lst in pairs:
        sea, air = lst
        dic[sea] = air
    return dic

def create_flight_times(pairs, dic):
    for lst in pairs:
        air, time = lst
        dic[air] = time
    return dic

create_coord(sea_points,sea_coord)
create_coord(air_points, air_coord)
create_codex(port_pairs, codex)
create_flight_times(flight_pairs, flight_times_sg)
###-------------------------------------------------------SEAPORT DATASET
# India (INNSA), China (CNQZH), Australia (AUMEL), New Zealand (NZAKL) and Singapore (SGSIN)
# More ports can be easily added with larger datasets.

ocean_df = pd.DataFrame(data = ocean_data)


def datetoint(x):
    #Convert datetimes into integers. It was easier to work with.
    return int(x.strftime("%Y%m%d%H%M%S"))
def inttodate(x):
    return datetime.strptime(str(x), "%Y%m%d%H%M%S")

def transit(start, end): #takes pandas dataseries as input
    #calculates the duration of a trip in days-HHMM formaat. time_correct function handles discrepancies that arise when comparing dates.
    #We assume that a route won't take longer than 2 years (time won't be calculated correctly otherwise).
    lst_s = start.tolist()
    lst_e = end.tolist()

    times = []
    for i in range(0, len(lst_s)):
        time = lst_e[i] - lst_s[i]
        time = time_correct(time / 1000000, lst_s[i], lst_e[i])
        times.append(time)
    return pd.Series(times)

ocean_df['Departs'] = ocean_df['Departs'].apply(datetoint)
ocean_df['Arrives'] = ocean_df['Arrives'].apply(datetoint)
ocean_df['Transit'] = transit(ocean_df['Departs'], ocean_df['Arrives'])

    
    
    

###------------------------------------------------------AIRPORT DATASET
freight_out = air_data.parse('FOutbound')
freight_in = air_data.parse('FInbound')
pass_out = air_data.parse('POutbound')
pass_in = air_data.parse('PInbound')


# 4 SHEETS - Pax Inbound/ Outbound, Freight Inbound/Outbound


def string(row):
    #had to rename the rows for flight_no.
    return str(row['Fltno'])

def calc_lt_date(dic, name, time, mode):
    #apply time_delta to get arrival dates from departure data,
    # and departure dates from arrival data,
    # based on estimated time of travel as recorded in flight_times_sg.
    lst_T = time.apply(inttodate).tolist()
    lst_N = name.tolist()
    if mode == 'ARR':
        for i in range(0, len(lst_T)):
            lst_T[i] += timedelta(days = dic[name[i]] / 24)

        return pd.Series(lst_T).apply(datetoint)

    if mode == 'DEP':
        for i in range(0, len(lst_T)):
            lst_T[i] -= timedelta(days = dic[name[i]] / 24)

        return pd.Series(lst_T).apply(datetoint)

#had to rename rows for LT DATEs as well. They weren't consistent across all sheets.

#freight_out, freight_in - exact arr/dep times found using FlightAware

freight_out['Air_Code'] = freight_out['Airline'] + freight_out.apply(lambda row: string(row), axis = 1)
freight_out['LT Date (DEP)'] = freight_out['LT Date (DEP)'].apply(datetoint) + freight_out['DTime'] * 100
freight_out['LT Date (ARR)'] = freight_out['LT Date (ARR)'].apply(datetoint) + freight_out['ATime'] * 100

freight_in['Air_Code'] = freight_in['Airline'] + freight_in.apply(lambda row: string(row), axis = 1)
freight_in['LT Date (DEP)'] = freight_in['LT Date (DEP)'].apply(datetoint) + freight_in['DTime'] * 100
freight_in['LT Date (ARR)'] = freight_in['LT Date (ARR)'].apply(datetoint) + freight_in['ATime'] * 100

freight_out['Transit'] = transit(freight_out['LT Date (DEP)'],freight_out['LT Date (ARR)'])
freight_in['Transit'] = transit(freight_in['LT Date (DEP)'],freight_out['LT Date (ARR)'])


#pass_out, pass_in - times of arr/dep calculated using flight_times_sg dictionary
pass_out['Air_Code'] = pass_out['Airline'] + pass_out.apply(lambda row: string(row), axis = 1)
pass_out['LT Date (DEP)'] = pass_out['LT Date (DEP)'].apply(datetoint) + pass_out['DTime'] * 100
pass_out['LT Date (ARR)'] = calc_lt_date(flight_times_sg, pass_out['Dest & Coord. Orig/Dest Stn'], pass_out['LT Date (DEP)'], 'ARR')

pass_in['Air_Code'] = pass_in['Airline'] + pass_in.apply(lambda row: string(row), axis = 1)
pass_in['LT Date (ARR)'] = pass_in['LT Date (ARR)'].apply(datetoint) + pass_in['ATime'] * 100
pass_in['LT Date (DEP)'] = calc_lt_date(flight_times_sg, pass_in['Orig'], pass_in['LT Date (ARR)'], 'DEP')

pass_out['Transit'] = transit(pass_out['LT Date (DEP)'], pass_out['LT Date (ARR)'])
pass_in['Transit'] = transit(pass_in['LT Date (DEP)'],pass_in['LT Date (ARR)'])
##----------------------------------PART II: Converting into Graph
##Implementing Dijkstra's Algorithm

##GENERATOR FUNCTIONS
##Nodes contain the name of the ports, type of port, and lat/long coordinates.
    #code - dataframe containing  names of port.
    #mode - type of port (sea / air)
    #dic - dictionary to hold all node objects.
    #lst - list to hold all node names.
    #coord - dictionary of ports lat/long coordinates.

    #TO BE IMPLEMENTED
    # remove - list of nodes NOT to generate. Akin to removing ports.

nodes = {}
names = []
def gen_nodes(code, mode, dic, lst, coord):
    for i in range(0, len(code)):
        if code[i] not in lst:
            node = Node(str(code[i]), mode)
            node.loc = coord[str(code[i])]
            dic[str(code[i])] = node
            lst.append(code[i])
        else:
            continue

#The edge links two nodes together, and attaches a few values:
    # weight - transit time, $$$, carbon emissions
    # start_time - from Departs
    # end_time - from Arrives
    # vessel_code - so we know which ship to take.
    # org_code - start node
    # dep_code - destination node
    
def gen_edges(weight, start_time, end_time, vessel_code, org_code, dep_code):
    for i in range(0, len(org_code)):
        if org_code[i] in nodes.keys():
            start_node = nodes[org_code[i]]
            end_node = nodes[dep_code[i]]
            start_node.add_edge(weight[i], end_node, start_time[i], end_time[i], vessel_code[i])


##GENERATE SEA NODES
orgport_code = ocean_df['Origin Code']
depport_code = ocean_df['Destination Code']
gen_nodes(orgport_code, "SEA", nodes, names, sea_coord)
gen_nodes(depport_code, "SEA",nodes,names, sea_coord)

print("Sea Ports \n")
for key in nodes.keys():
    if nodes[key].mode == 'SEA':
        print(key)
print("\n")

##GENERATE AIR NODES


##Singapore is a port for all trips, so initialise first.
SIN = Node('SIN', 'AIR')
nodes['SIN'] = SIN
names.append('SIN')
SIN.loc = air_coord['SIN']

fout_code = freight_out['Dest & Coord. Orig/Dest Stn']
fin_code = freight_in['Orig']
pout_code = pass_out['Dest & Coord. Orig/Dest Stn']
pin_code = pass_in['Orig']

gen_nodes(fout_code, "AIR",nodes,names, air_coord)
gen_nodes(fin_code, "AIR", nodes, names, air_coord)
gen_nodes(pout_code, "AIR",nodes,names, air_coord)
gen_nodes(pin_code, "AIR", nodes, names, air_coord)

print("Air Ports \n")
for key in nodes.keys():
    if nodes[key].mode == 'AIR':
        print(key)
print("\n")

    

start_time = ocean_df['Departs']
end_time = ocean_df['Arrives']
imo = ocean_df['IMO Number']

        
## Connect airports and sea ports in the same country first.
#Assume negligible cost in time, money, carbon.

for key, value in codex.items():
    if key in nodes.keys() and value in nodes.keys():
        nodes[key].add_edge(0,nodes[value], None, None, "Multi!")
        nodes[value].add_edge(0,nodes[key], None, None, "Multi!")
        
        
##----------------------------------PART III: Select Optimiser, Constraints

##I want the shortest transit time!
opti = None
time_con = None
cost_con = None
carbon_con = None

##----------------------------------PART IV: Run the Algorithm, Take User Input, Return Results
algorithm = Dijkstra()
print("Welcome to the KAAAndle Maritime Route Optimiser! Please select a start and end port from the options above!")
user_start = input("Please enter a start port: ").upper()
user_end = input("Please enter an end port: ").upper()
user_depart = int(input("Please key in the date of departure (YYYYMMDD): ")) * 1000000
print("0 - time, 1 - cost, 2 - carbon emissions")
opti = int(input("Please key in the number of the parameter to optimise: "))

if opti == 0:
      o_weight = ocean_df['Transit'] #Can be changed to $, carbon emission if data is available.
      a_weight = 'Transit'


#Create the edges!
#This is where the magic happens baby
    
gen_edges(o_weight, start_time, end_time, imo, orgport_code, depport_code)
gen_edges(freight_out[a_weight], freight_out['LT Date (DEP)'], freight_out['LT Date (ARR)'], freight_out['Air_Code'], ['SIN',]* len(fout_code), fout_code)
gen_edges(freight_in[a_weight], freight_in['LT Date (DEP)'], freight_in['LT Date (ARR)'], freight_in['Air_Code'],fin_code, ['SIN',] * len(fin_code))
gen_edges(pass_out[a_weight], pass_out['LT Date (DEP)'], pass_out['LT Date (ARR)'], pass_out['Air_Code'], ['SIN',]* len(pout_code), pout_code)
gen_edges(pass_in[a_weight], pass_in['LT Date (DEP)'], pass_in['LT Date (ARR)'], pass_in['Air_Code'],pin_code, ['SIN',] * len(pin_code))

if user_start not in nodes.keys() or user_end not in nodes.keys():
    print("The port(s) that you have chosen do not exist!")
if len(str(user_depart)) != 14:
    print("You have entered an invalid date.")
    
else:
    route = algorithm.calculate(nodes[user_start], user_depart, opti)
    algorithm.get_shortest_path(nodes[user_end], route)

        
        
    

